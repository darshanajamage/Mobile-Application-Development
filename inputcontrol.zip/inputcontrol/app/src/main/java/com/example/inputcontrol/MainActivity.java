package com.example.inputcontrol;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    private Spinner spinnerDept;
    private RadioGroup radioGroupExp;
    private CheckBox checkAI, checkWeb, checkMobile;
    private ToggleButton toggleWeekend;
    private Button btnSubmit;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        spinnerDept = findViewById(R.id.spinnerDept);
        radioGroupExp = findViewById(R.id.radioGroupExp);
        checkAI = findViewById(R.id.checkAI);
        checkWeb = findViewById(R.id.checkWeb);
        checkMobile = findViewById(R.id.checkMobile);
        toggleWeekend = findViewById(R.id.toggleWeekend);
        btnSubmit = findViewById(R.id.btnSubmit);
        tvResult = findViewById(R.id.tvResult);

        // Spinner Data
        String[] departments = {"CSE", "ECE", "MECH", "CIVIL"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                departments);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDept.setAdapter(adapter);

        // Submit button click
        btnSubmit.setOnClickListener(view -> {
            StringBuilder result = new StringBuilder();

            // Spinner
            result.append("Department: ").append(spinnerDept.getSelectedItem().toString()).append("\n");

            // RadioGroup
            int selectedId = radioGroupExp.getCheckedRadioButtonId();
            if (selectedId != -1) {
                RadioButton selectedRadio = findViewById(selectedId);
                result.append("Experience: ").append(selectedRadio.getText()).append("\n");
            } else {
                result.append("Experience: Not selected\n");
            }

            // CheckBoxes
            result.append("Skills: ");
            if (checkAI.isChecked()) result.append("AI ");
            if (checkWeb.isChecked()) result.append("Web ");
            if (checkMobile.isChecked()) result.append("Mobile ");
            result.append("\n");

            // ToggleButton
            result.append("Availability: ").append(toggleWeekend.isChecked() ? "Weekend" : "Weekday");

            // Display in TextView
            tvResult.setText(result.toString());
        });
    }
}