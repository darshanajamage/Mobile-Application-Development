package com.example.filehandling;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {

    Button b1, b2;
    TextView tv;
    EditText ed1;

    String file = "mydata.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.buttonSave);
        b2 = findViewById(R.id.buttonLoad);
        ed1 = findViewById(R.id.editText);
        tv = findViewById(R.id.textview2);

        // SAVE BUTTON
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String data = ed1.getText().toString();

                try {
                    FileOutputStream fOut = openFileOutput(file, MODE_PRIVATE);
                    fOut.write(data.getBytes());
                    fOut.close();

                    Toast.makeText(MainActivity.this, "File Saved", Toast.LENGTH_SHORT).show();
                    ed1.setText("");

                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Error saving file", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });

        // LOAD BUTTON
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    FileInputStream fin = openFileInput(file);
                    int c;
                    String temp = "";

                    while ((c = fin.read()) != -1) {
                        temp += Character.toString((char) c);
                    }

                    fin.close();
                    tv.setText(temp);

                    Toast.makeText(MainActivity.this, "File Loaded", Toast.LENGTH_SHORT).show();

                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Error reading file", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });
    }
}