package com.example.explicitintentapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS, Manifest.permission.CALL_PHONE},
                1);

        Button btnSms = findViewById(R.id.btnSms);
        Button btnCall = findViewById(R.id.btnCall);
        Button btnSettings = findViewById(R.id.btnSettings);
        Button btnNetwork = findViewById(R.id.btnNetwork);

        btnSms.setOnClickListener(v -> {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                SmsManager.getDefault().sendTextMessage(
                        "1234567890", null, "Hello from Explicit Intent App", null, null);
                Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT).show();
            }
        });

        btnCall.setOnClickListener(v -> {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                    == PackageManager.PERMISSION_GRANTED) {
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:1234567890"));
                startActivity(i);
            }
        });

        btnSettings.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_SETTINGS)));

        btnNetwork.setOnClickListener(v -> {
            ConnectivityManager cm =
                    (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info = cm.getActiveNetworkInfo();
            Toast.makeText(this,
                    info != null && info.isConnected() ? info.getTypeName() : "No Network",
                    Toast.LENGTH_LONG).show();
        });
    }
}
