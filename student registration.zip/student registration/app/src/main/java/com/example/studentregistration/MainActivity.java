package com.example.studentregistration;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText etName, etRoll, etClass, etMobile;
    Button btnSubmit;
    ListView listView;

    ArrayList<String> studentList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etRoll = findViewById(R.id.etRoll);
        etClass = findViewById(R.id.etClass);
        etMobile = findViewById(R.id.etMobile);
        btnSubmit = findViewById(R.id.btnSubmit);
        listView = findViewById(R.id.listView);

        studentList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, studentList);
        listView.setAdapter(adapter);

        btnSubmit.setOnClickListener(v -> {
            String data = etName.getText().toString() + " | " +
                    etRoll.getText().toString() + " | " +
                    etClass.getText().toString() + " | " +
                    etMobile.getText().toString();

            studentList.add(data);
            adapter.notifyDataSetChanged();

            etName.setText("");
            etRoll.setText("");
            etClass.setText("");
            etMobile.setText("");
        });
    }
}
